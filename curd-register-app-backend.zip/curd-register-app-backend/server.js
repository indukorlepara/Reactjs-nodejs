// server.js
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');
const Education = require('./models/Education');
const Tester = require('./models/Tester');

// Create an express app
const app = express();
const secretKey =process.env.SECRET_KEY;  // This is the key you use to verify the token later


// Middleware
app.use(cors());
app.use(bodyParser.json());  // For parsing application/json

// MongoDB connection (Replace with your MongoDB connection string)
mongoose.connect('mongodb+srv://indukin:cqTmerndIyqHw8rY@cluster0.dkb1w.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// User schema and model
const userSchema = new mongoose.Schema({
  username: String,
  password: String,
});

const User = mongoose.model('User', userSchema);

const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1]; // Extract token from header

  if (!token) return res.sendStatus(403); // Forbidden if no token is found

  jwt.verify(token,secretKey,(err, decode) => {
  
    if (err) {
      if (err.name === 'TokenExpiredError') {
        console.error('Token has expired');
        return res.status(403).json({ message: 'Token has expired' });
      } else if (err.name === 'JsonWebTokenError') {
        console.error('Invalid signature');
        return res.status(403).json({ message: 'Invalid token signature' });
      } else {
        console.error('Error verifying token', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
    } else {
      console.log('Decoded payload:', decode);
      // Proceed with your application logic (e.g., attach user data to request)
      req.user = decode;
      next(); // Pass to the next middleware or route handler
    }

  });
  
};

// API endpoint for registering a new user
app.post('/register', async (req, res) => {
  const { username, password } = req.body;

  // Check if username already exists
  const existingUser = await User.findOne({ username });
  if (existingUser) {
    return res.status(400).json({ message: 'Username already exists' });
  }

  // Hash password before saving it
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create a new user and save to the database
  const newUser = new User({ username, password: hashedPassword });
  await newUser.save();

  res.status(201).json({ message: 'User registered successfully' });
});

// API endpoint for logging in
app.post('/login', async (req, res) => {

  const { username, password } = req.body;

  // Find the user by username
  const user = await User.findOne({ username });
  if (!user) {
    return res.status(400).json({ message: 'Invalid credentials' });
  }

  // Check if password is correct
  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    return res.status(400).json({ message: 'Invalid credentials' });
  }

  const payload = {
    username: user.username,
  };

  // Create a JWT token
  const token = jwt.sign(payload,secretKey, {
    expiresIn: '1h', // Token expiration time
  });

  res.status(200).json({ token });
});

app.get('/education', authenticateJWT, async (req, res) => {
  try {
    // Fetch education details for the authenticated user (based on userId)
    const educationDetails = await Education.find({ username:req.user.username }).populate('username');
    if (!educationDetails || educationDetails.length === 0) {
      return res.status(404).json({ message: 'No education details found' });
    }

    // Send the education details along with the username
    res.status(200).json({
      educationDetails
    });
  } catch (err) {
    console.error('Error fetching education details:', err);
    res.status(500).json({ message: 'Error fetching education details', error: err.message });
  }
});


// POST /education - Add new education details (requires authentication)
app.post('/education', authenticateJWT, async (req, res) => {
  const { username,degree, institution, graduationYear } = req.body;

  // Check if all fields are provided
  if (!degree || !institution || !graduationYear) {
    return res.status(400).send('Missing required fields');
  }
 const newEducation = new Education({username,degree, institution, graduationYear });
 await newEducation.save();

 

  res.status(201).send({ message: 'Education details saved successfully', newEducation });
});


app.post('/submit-form', async (req, res) => {
  const { name, email } = req.body;

  // Check if username already exists
  const existingTester = await Tester.findOne({ name });
  if (existingTester) {
    return res.status(400).json({ message: 'name already exists' });
  }

 // Create a new user and save to the database
  const newTester = new Tester({ name, email });
  await newTester.save();

  res.status(201).json({ message: 'Tester registered successfully' });
});


// Start the server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

