// src/components/EducationForm.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const EducationForm = () => {
  const [degree, setDegree] = useState('');
  const [institution, setInstitution] = useState('');
  const [graduationYear, setGraduationYear] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const username = localStorage.getItem('user');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem('token');
    if (!token) {
      setError('You need to be logged in to submit your education details.');
      return;
    }

    try {
       await axios.post(
        'http://localhost:5000/education',  // Your backend API endpoint
        {
         username,
          degree,
          institution,
          graduationYear,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,  // Pass the token in the request header
          },
        }
      );

      // Clear the form
      setDegree('');
      setInstitution('');
      setGraduationYear('');
      setError('');
      
      // Navigate to home page after successful submission
      navigate('/home');
    } catch (err) {
      setError('Failed to submit education details. Please try again.');
    }
  };

  return (
    <div>
      <h3>Enter Your Education Details</h3>
      <h1>Welcome, {username}!</h1>
      <form onSubmit={handleSubmit}>
     
        <div>
          <label>Degree</label>
          <input
            type="text"
            value={degree}
            onChange={(e) => setDegree(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Institution</label>
          <input
            type="text"
            value={institution}
            onChange={(e) => setInstitution(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Graduation Year</label>
          <input
            type="text"
            value={graduationYear}
            onChange={(e) => setGraduationYear(e.target.value)}
            required
          />
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default EducationForm;
