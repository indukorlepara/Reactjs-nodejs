// src/components/HomePage.js
import React from 'react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');  // Remove user info from localStorage
    navigate('/');  // Redirect to login page after logout
  };

  const username = localStorage.getItem('user');
  return (
    <div>
      <h3>Welcome to the  {username}!</h3>
      <button onClick={handleLogout}>Log Out</button>
    </div>
  );
};

export default HomePage;
