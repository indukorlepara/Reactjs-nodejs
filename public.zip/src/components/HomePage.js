// src/components/HomePage.js
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const HomePage = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  console.log(token);

  const handleLogout = () => {
    localStorage.removeItem('user');  // Remove user info from localStorage
    navigate('/');  // Redirect to login page after logout
  };

  const username = localStorage.getItem('user');

  const [educationDetails, setEducationDetails] = useState([]);
  
  useEffect(() => {
    if (!token) {
      navigate('/'); // Redirect to login if not authenticated
      return;
    }

    // Fetch education details for the logged-in user
    const fetchEducationDetails = async () => {
      try {
        const response = await axios.get('http://localhost:5000/education', {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log(response.data.educationDetails);
        setEducationDetails(response.data.educationDetails); // Assume the backend sends back an array of education details
      } catch (err) {
        console.error('Error fetching education details:', err);
      }
    };

    fetchEducationDetails();
  }, [token, navigate]);

  return (
      <div>
      <h1>Welcome, {username}!</h1>
      <h2>Your Education Details</h2>
      <button onClick={handleLogout}>Log Out</button>
      <button onClick={() => navigate('/education')}>Add Education Details</button>
      {educationDetails.length > 0 ? (
        educationDetails.map((edu, index) => (
          <div key={index}>
            <p>Degree: {edu.degree}</p>
            <p>Institution: {edu.institution}</p>
            <p>Graduation Year: {edu.graduationYear}</p>
            <hr />
          </div>
          
        ))
        
      ) : (
        <p>No education details found. Please enter your details.
        </p>
      )}
    </div>

  );
  
};

export default HomePage;

// // src/components/HomePage.js
// import React, { useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';

// const HomePage = () => {
//   const [educationDetails, setEducationDetails] = useState([]);
//   const navigate = useNavigate();

//   const token = localStorage.getItem('token');
//   const username = localStorage.getItem('username');

//   useEffect(() => {
//     if (!token) {
//       navigate('/'); // Redirect to login if not authenticated
//       return;
//     }

//     // Fetch education details for the logged-in user
//     const fetchEducationDetails = async () => {
//       try {
//         const response = await axios.get('http://localhost:5000/education', {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         setEducationDetails(response.data); // Assume the backend sends back an array of education details
//       } catch (err) {
//         console.error('Error fetching education details:', err);
//       }
//     };

//     fetchEducationDetails();
//   }, [token, navigate]);

//   return (
  
//   );
// };

// export default HomePage;
