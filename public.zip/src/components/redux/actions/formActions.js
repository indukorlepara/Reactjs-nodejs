import axios from "axios";

// Action Types
export const FORM_SUBMIT = "FORM_SUBMIT";
export const FORM_ERROR = "FORM_ERROR";

// Action Creators
export const submitForm = (formData) => async (dispatch) => {
  try {
    const response = await axios.post("http://localhost:5000/submit-form", formData);
    dispatch({ type: FORM_SUBMIT, payload: response.data });
  } catch (error) {
    dispatch({ type: FORM_ERROR, payload: error.message });
  }
};
