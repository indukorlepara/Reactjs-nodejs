import { FORM_SUBMIT, FORM_ERROR } from "../actions/formActions";

const initialState = {
  message: "",
  error: "",
};

const formReducer = (state = initialState, action) => {
  switch (action.type) {
    case FORM_SUBMIT:
      return {
        ...state,
        message: action.payload.message,
        error: "",
      };
    case FORM_ERROR:
      return {
        ...state,
        error: action.payload,
        message: "",
      };
    default:
      return state;
  }
};

export default formReducer;
