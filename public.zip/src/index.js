// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom'; // Import BrowserRouter
import App from './App';
import './index.css';
import { Provider } from "react-redux";  // Import Provider for Redux
import store from "../src/components/redux/store"; 

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>  {/* Providing the Redux store */}
    <Router>  {/* Wrapping the App with Router */}
      <App />  {/* Your main App component */}
    </Router>
  </Provider>
);
